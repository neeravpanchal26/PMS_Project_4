create
  definer = PMS@`%` procedure uspAddProperty_ImageUpload(IN image longblob)
BEGIN
  SET @propID = (SELECT MAX(p.PropertyID) FROM Property AS p);
  SET @imgID = (SELECT MAX(pi.imageID)+1 FROM PropertyImages AS pi);

  INSERT INTO `pms_schema`.`PropertyImages`
  (`ResidenceID`,
   `ResidenceImagescol`,
   `imageID`)
  VALUES
  (@propID,
    image,
    @imgID);
END;

