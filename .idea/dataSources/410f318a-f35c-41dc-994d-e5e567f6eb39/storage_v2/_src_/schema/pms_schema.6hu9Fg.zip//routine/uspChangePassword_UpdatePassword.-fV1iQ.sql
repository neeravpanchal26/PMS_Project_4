create
    definer = pms@`%` procedure uspChangePassword_UpdatePassword(IN userID int, IN userPass varchar(20))
BEGIN
  DECLARE errno INT;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
      GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
      SELECT errno AS MYSQL_ERROR;
      ROLLBACK;
    END;

  START TRANSACTION;
  SET autocommit=0;
  SET @salt = UNHEX(SHA1(CONCAT(RAND(), RAND(), RAND())));
  SET @ehash = UNHEX(SHA1(CONCAT(HEX(@salt), userPass)));
  UPDATE user
  SET
    User.Salt = @salt,
    User.Hash = @ehash
  WHERE User.UserID = userID;

  IF( row_count() > 0) THEN
    SELECT TRUE;
  END IF;
  COMMIT WORK;
END;

