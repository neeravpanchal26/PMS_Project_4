create
    definer = pms@`%` procedure uspManageSupplier_Suppliers()
BEGIN
    SELECT s.SupplierID, s.Name, s.contactNumber, s.email, s.Active
    FROM Supplier AS s;
END;

