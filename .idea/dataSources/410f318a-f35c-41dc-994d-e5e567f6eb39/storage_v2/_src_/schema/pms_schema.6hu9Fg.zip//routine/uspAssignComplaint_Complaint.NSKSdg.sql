create
    definer = pms@`%` procedure uspAssignComplaint_Complaint()
BEGIN
    SELECT c.ComplaintID,
           c.`Desc`,
           c.Date,
           csc.Name                            AS catName,
           p.Name                              AS propName,
           CONCAT(u.FirstName, ' ', u.Surname) AS tenantName,
           cs.`Desc`                           AS statusDesc,
           CONCAT(p.Address1,' ',p.Address2,' ',s.SuburbName,' ',ci.CityName) AS address,
           u.ContactNumber


    FROM Complaint AS c,
         ComplaintSubCategory AS csc,
         ComplaintStatus AS cs,
         Property AS p,
         User AS u,
         Suburb AS s,
         City AS ci
    WHERE c.subCategoryID = csc.SubID
      AND c.Status = cs.ComplaintStatusID
      AND c.propertyID = p.PropertyID
      AND c.tenantID = u.UserID
      AND s.SuburbID = p.Suburb
      AND ci.CityID = s.CityID
      AND c.Status = 1
    ORDER BY c.Date DESC;
END;

