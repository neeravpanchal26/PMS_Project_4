create
    definer = pms@`%` procedure uspAssignProperty_PropertyImages(IN imgID int)
BEGIN
  SELECT pi.ResidenceImagescol
  FROM PropertyImages AS pi
  WHERE pi.imageID = imgID;
END;

