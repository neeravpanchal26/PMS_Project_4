create
    definer = pms@`%` procedure uspUpdateComplaint_Status()
BEGIN
    SELECT cs.ComplaintStatusID, cs.`Desc`
    FROM ComplaintStatus AS cs
    WHERE cs.ComplaintStatusID = 3
      OR cs.ComplaintStatusID = 4;
END;

