create
    definer = pms@`%` procedure uspAssignProperty_PropertyImageID(IN propertyID int)
BEGIN
  SELECT MIN(pi.imageID) AS minID, MAX(pi.imageID) AS maxID
  FROM PropertyImages AS pi
  WHERE pi.ResidenceID = propertyID;
END;

