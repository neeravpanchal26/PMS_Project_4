create
    definer = pms@`%` procedure uspDashboardMaintenanceSupervisor_Complaints(IN days int)
BEGIN
    SELECT COUNT(c.ComplaintID) AS counter, DATE(c.Date) AS 'reportedDate'
    FROM Complaint AS c
    WHERE c.Date BETWEEN NOW() + INTERVAL - days DAY AND NOW() + INTERVAL 0 DAY
    GROUP BY DATE(c.Date);
END;

