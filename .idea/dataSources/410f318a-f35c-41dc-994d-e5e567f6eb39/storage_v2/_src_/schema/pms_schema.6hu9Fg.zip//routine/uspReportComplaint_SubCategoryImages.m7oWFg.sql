create
    definer = pms@`%` procedure uspReportComplaint_SubCategoryImages(IN subID int)
BEGIN
    SELECT csc.Image
    FROM ComplaintSubCategory AS csc
    WHERE csc.SubID = subID;
END;

