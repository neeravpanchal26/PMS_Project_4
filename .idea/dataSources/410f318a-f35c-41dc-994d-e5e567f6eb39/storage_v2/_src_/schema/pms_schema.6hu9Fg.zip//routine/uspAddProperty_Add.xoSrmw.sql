create
    definer = pms@`%` procedure uspAddProperty_Add(IN Name varchar(45), IN Address1 varchar(45),
                                                   IN Address2 varchar(45), IN Suburb int, IN YearBuilt varchar(4),
                                                   IN PropType int, IN Owner int, IN Bedrooms int, IN Bathrooms int,
                                                   IN Size int, IN PropStatus int)
BEGIN
  -- Error Handling
  DECLARE errno INT;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
      GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
      SELECT errno AS MYSQL_ERROR;
      ROLLBACK;
    END;

  START TRANSACTION;
  SET autocommit = 0;
  SET @propID = (SELECT MAX(p.PropertyID) + 1 FROM Property AS p);

  # Statement here
  INSERT INTO `pms_schema`.`Property`
  (`PropertyID`,
   `Name`,
   `Address1`,
   `Address2`,
   `Suburb`,
   `YearBuilt`,
   `Type`,
   `TenantID`,
   `OwnerID`,
   `Active`,
   `Bedrooms`,
   `Bathrooms`,
   `Size`,
   `Status`)
  VALUES
  (@propID,
    Name,
    Address1,
    Address2,
    Suburb,
    YearBuilt,
    PropType,
    null,
    Owner,
    1,
    Bedrooms,
    Bathrooms,
    Size,
    PropStatus);

  IF (row_count() > 0) THEN
    SELECT TRUE;
  END IF;
  COMMIT WORK;
END;

