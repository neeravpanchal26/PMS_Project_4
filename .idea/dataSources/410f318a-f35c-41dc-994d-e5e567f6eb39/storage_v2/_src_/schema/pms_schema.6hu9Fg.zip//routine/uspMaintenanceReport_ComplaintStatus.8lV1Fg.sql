create
    definer = pms@`%` procedure uspMaintenanceReport_ComplaintStatus()
BEGIN
    SELECT *
    FROM ComplaintStatus AS cs;
END;

