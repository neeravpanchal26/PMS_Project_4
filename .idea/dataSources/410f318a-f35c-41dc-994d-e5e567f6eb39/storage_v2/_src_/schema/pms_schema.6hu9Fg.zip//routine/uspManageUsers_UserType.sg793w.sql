create
    definer = pms@`%` procedure uspManageUsers_UserType()
BEGIN
    SELECT *
    FROM UserType AS ut;
END;

