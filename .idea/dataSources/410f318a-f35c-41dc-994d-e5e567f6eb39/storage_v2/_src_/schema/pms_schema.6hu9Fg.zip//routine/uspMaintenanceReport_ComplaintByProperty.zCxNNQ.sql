create
    definer = pms@`%` procedure uspMaintenanceReport_ComplaintByProperty(IN propID int)
BEGIN
    SELECT c.ComplaintID, c.Date, csc.Name
    FROM Complaint AS c,
         ComplaintSubCategory AS csc
    WHERE c.subCategoryID = csc.SubID
      AND c.propertyID = propID;
END;

