create
    definer = pms@`%` procedure uspReportComplaint_SubCategory(IN catID int)
BEGIN
    SELECT csc.SubID, csc.Name
    FROM ComplaintSubCategory AS csc
    WHERE csc.CategoryID = catID;
END;

