create
    definer = pms@`%` procedure uspReportComplaint_Image(IN image longblob)
BEGIN
    SET @compID = (SELECT MAX(c.ComplaintID) FROM Complaint AS c);

    UPDATE Complaint AS c
    SET c.Image = image
    WHERE c.ComplaintID = @compID;
END;

