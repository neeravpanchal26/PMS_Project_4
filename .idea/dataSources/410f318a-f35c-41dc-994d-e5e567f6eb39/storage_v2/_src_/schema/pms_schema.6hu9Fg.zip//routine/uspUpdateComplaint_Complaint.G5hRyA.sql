create
    definer = pms@`%` procedure uspUpdateComplaint_Complaint()
BEGIN
    SELECT c.ComplaintID, c.Date,csc.Name,CONCAT(u.FirstName,' ',u.Surname) AS tenantName,u.Email,p.Name AS propertyName
    FROM Complaint AS c,
         ComplaintSubCategory AS csc,
         User AS u,
         Property AS p
    WHERE c.subCategoryID = csc.SubID
      AND p.PropertyID = c.propertyID
      AND c.tenantID = u.UserID
      AND c.Status != 4;
END;

