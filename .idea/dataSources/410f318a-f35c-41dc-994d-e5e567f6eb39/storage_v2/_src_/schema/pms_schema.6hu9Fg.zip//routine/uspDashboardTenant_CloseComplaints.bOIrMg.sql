create
    definer = pms@`%` procedure uspDashboardTenant_CloseComplaints(IN tenantID int)
BEGIN
    SELECT COUNT(DISTINCT (c.ComplaintID)) AS totalComplaints
    FROM ComplaintDetails AS cd,
         Complaint AS c
    WHERE cd.complaintID = c.ComplaintID
      AND c.tenantID = tenantID
      AND c.Status = 4;
END;

