create
    definer = pms@`%` procedure uspReportComplaint_CategoryImages(IN catID int)
BEGIN
   SELECT cc.Image
   FROM ComplaintCategory AS cc
   WHERE cc.CategoryID = catID;
END;

