create
    definer = pms@`%` procedure uspMaintenanceReport_Property(IN ownerName varchar(100), IN suburbName varchar(45),
                                                              IN cityName varchar(45), IN startDate datetime,
                                                              IN endDate datetime)
BEGIN
    SELECT p.Name,
           p.Address1,
           p.Address2,
           s.SuburbName,
           ci.CityName,
           CONCAT(o.Firstname, ' ', o.Lastname)                AS ownerFullName,
           COUNT(c.ComplaintID)                               AS totalComplaint
    FROM Property AS p,
         Complaint AS c,
         Suburb AS s,
         Owner AS o,
         City AS ci,
         (SELECT COUNT(ComplaintID) FROM Complaint, Property WHERE Complaint.Status != 4 AND Property.PropertyID = Complaint.propertyID GROUP BY Complaint.propertyID) AS unresolvedComplaint,
         (SELECT COUNT(ComplaintID) FROM Complaint, Property WHERE Complaint.Status = 4 AND Property.PropertyID = Complaint.propertyID GROUP BY Complaint.propertyID) AS resolvedComplaint
    WHERE c.propertyID = p.PropertyID
      AND s.SuburbID = p.Suburb
      AND p.OwnerID = o.OwnerID
      AND ci.CityID = s.CityID
      AND CONCAT(o.Firstname, ' ', o.Lastname) LIKE CONCAT(ownerName, '%')
      AND s.SuburbName LIKE CONCAT(suburbName, '%')
      AND ci.CityName LIKE CONCAT(cityName, '%')
      AND c.Date BETWEEN startDate AND endDate
    GROUP BY c.propertyID;
END;

