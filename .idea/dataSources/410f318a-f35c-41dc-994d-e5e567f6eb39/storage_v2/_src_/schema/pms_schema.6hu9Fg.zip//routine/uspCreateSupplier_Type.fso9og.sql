create
    definer = pms@`%` procedure uspCreateSupplier_Type()
BEGIN
	SELECT *
    FROM SupplierType;
END;

