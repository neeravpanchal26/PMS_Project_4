create
  definer = pms@`%` procedure uspDashboardItTechnician_Users(IN days int)
BEGIN
  SELECT u.UserID,u.FirstName, u.Surname, COUNT(lh.LoginHistoryID) AS count, MAX(lh.LoginHistoryDate) As lastAccess
  FROM User AS u, LoginHistory AS lh
  WHERE u.UserID = lh.LoginHistoryID AND
    lh.LoginHistoryDate between NOW() + INTERVAL -days DAY AND NOW() + INTERVAL  0 DAY
  GROUP BY lh.LoginHistoryID;
END;

