create
  definer = PMS@`%` procedure uspBusinessSetting_Info()
BEGIN
  SELECT b.BusinessName, c.CityName, b.BusinessWebsite, b.BusinessContact, b.BusinessVat, b.BusinessCity
  FROM Business AS b,
       City AS c
  WHERE b.BusinessCity = c.CityID
    AND b.BusinessID = 1;
END;

