create
    definer = pms@`%` procedure uspMaintenanceReport_ComplaintHistory(IN propName varchar(45), IN complaint varchar(45),
                                                                      IN subCat varchar(45), IN cat varchar(45),
                                                                      IN supplier varchar(45),
                                                                      IN complaintStatus varchar(45),
                                                                      IN startDate varchar(10), IN endDate varchar(10))
BEGIN
    SELECT CD.Date, CD.`Desc`
    FROM ComplaintDetails AS CD,
         Complaint AS C,
         Property AS P,
         Supplier AS S,
         SupplierType AS ST,
         ComplaintSubCategory AS CSC,
         ComplaintCategory AS CC,
         ComplaintStatus AS CS
    WHERE CD.complaintID = C.ComplaintID
      AND C.propertyID = P.PropertyID
      AND CD.supplierID = S.SupplierID
      AND C.subCategoryID = CSC.SubID
      AND CC.CategoryID = CSC.CategoryID
      AND CD.statusID = CS.ComplaintStatusID
      AND S.typeID = ST.SupplierTypeID
      AND p.Name LIKE CONCAT(propName, '%')
      AND CONCAT(CSC.Name, ' - (', CD.Date, ')') LIKE (complaint, '%')
      AND CSC.Name LIKE CONCAT(subCat, '%')
      AND CC.Name LIKE CONCAT(cat, '%')
      AND CS.`Desc` LIKE CONCAT(complaintStatus, '%')
      AND CONCAT(S.Name, ' - (', ST.`Desc`, ')') LIKE CONCAT(supplier, '%')
      AND CD.Date BETWEEN startDate AND endDate;
END;

