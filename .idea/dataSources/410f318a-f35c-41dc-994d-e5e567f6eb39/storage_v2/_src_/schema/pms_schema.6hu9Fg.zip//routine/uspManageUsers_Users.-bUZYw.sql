create
    definer = pms@`%` procedure uspManageUsers_Users(IN id int)
BEGIN
	SELECT u.UserID,CONCAT(u.FirstName, ' ',u.Surname) AS username, u.Email, u.Type, u.Active
	FROM User AS u
	WHERE u.UserID NOT IN (id)
	ORDER BY u.Active ASC; 
END;

