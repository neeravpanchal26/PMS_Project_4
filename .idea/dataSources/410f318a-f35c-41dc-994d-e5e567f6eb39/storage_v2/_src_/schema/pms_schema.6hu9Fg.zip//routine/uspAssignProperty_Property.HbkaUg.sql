create
  definer = pms@`%` procedure uspAssignProperty_Property()
BEGIN
  SELECT p.PropertyID,p.Name
  FROM Property AS p;
END;

