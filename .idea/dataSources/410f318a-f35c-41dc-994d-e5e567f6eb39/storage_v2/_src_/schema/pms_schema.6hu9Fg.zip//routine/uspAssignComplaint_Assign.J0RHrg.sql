create
    definer = pms@`%` procedure uspAssignComplaint_Assign(IN compID int, IN suppID int)
BEGIN
    -- Error Handling
    DECLARE errno INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
            SELECT errno AS MYSQL_ERROR;
            ROLLBACK;
        END;

    START TRANSACTION;
    SET autocommit = 0;
    SET @compDetailID = (SELECT MAX(cd.ComplaintDetailsID) + 1 FROM ComplaintDetails AS cd);
    SET @suppName = (SELECT s.Name FROM Supplier AS s WHERE s.SupplierID = suppID);
    SET @suppCon = (SELECT s.contactNumber FROM Supplier AS s WHERE s.SupplierID = suppID);

    # Statement here
    INSERT INTO `pms_schema`.`ComplaintDetails`
    (`ComplaintDetailsID`,
     `complaintID`,
     `supplierID`,
     `statusID`,
     `Desc`,
     `Date`)
    VALUES (@compDetailID,
            compID,
            suppID,
            2,
            CONCAT('This complaint has been assigned to: ', @suppName, '. For further information please contact on: ',
                   @suppCon, '.'),
            NOW());

    UPDATE `pms_schema`.`Complaint`
    SET `Status` = 2
    WHERE `ComplaintID` = compID;

    IF (row_count() > 0) THEN
        SELECT TRUE;
    END IF;
    COMMIT WORK;
END;

