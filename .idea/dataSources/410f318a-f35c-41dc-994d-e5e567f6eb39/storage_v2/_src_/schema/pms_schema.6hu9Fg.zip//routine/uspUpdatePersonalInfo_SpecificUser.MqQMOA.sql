create
  definer = PMS@`%` procedure uspUpdatePersonalInfo_SpecificUser(IN userID int)
BEGIN
  SELECT u.FirstName, u.Surname,u.Dob,u.ContactNumber,u.Email,u.Address1,u.Address2,u.Suburb,c.CityID
  FROM User AS u, City AS c, Suburb AS s
  WHERE u.UserID = userID AND u.Suburb = s.SuburbID AND s.CityID = c.CityID;
END;

