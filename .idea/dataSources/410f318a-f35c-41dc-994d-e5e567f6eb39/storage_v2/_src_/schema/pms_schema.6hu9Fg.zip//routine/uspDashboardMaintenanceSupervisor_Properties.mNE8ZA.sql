create
    definer = pms@`%` procedure uspDashboardMaintenanceSupervisor_Properties()
BEGIN
    SELECT COUNT(p.PropertyID) AS totalProperty
    FROM Property AS p
    WHERE p.Active = 1;
END;

