create
    definer = pms@`%` procedure uspReportComplaint_Category()
BEGIN
   SELECT cc.CategoryID,cc.Name, cc.Description
   FROM ComplaintCategory AS cc;
END;

