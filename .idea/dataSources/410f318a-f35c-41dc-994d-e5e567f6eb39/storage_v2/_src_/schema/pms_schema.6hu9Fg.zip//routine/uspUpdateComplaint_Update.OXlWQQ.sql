create
    definer = pms@`%` procedure uspUpdateComplaint_Update(IN compID int, IN description varchar(200), IN status int)
BEGIN
    -- Error Handling
    DECLARE errno INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
            SELECT errno AS MYSQL_ERROR;
            ROLLBACK;
        END;

    START TRANSACTION;
    SET autocommit = 0;
    SET @compDetailID = (SELECT MAX(cd.ComplaintDetailsID) + 1 FROM ComplaintDetails AS cd);
    SET @suppID = (SELECT cd.supplierID FROM ComplaintDetails AS cd WHERE cd.complaintID = compID);

    # Statement here
    INSERT INTO `pms_schema`.`ComplaintDetails`
    (`ComplaintDetailsID`,
     `complaintID`,
     `supplierID`,
     `statusID`,
     `Desc`,
     `Date`)
    VALUES (@compDetailID,
            compID,
            @suppID,
            status,
            description,
            NOW());

    UPDATE `pms_schema`.`Complaint`
    SET `Status` = status
    WHERE `ComplaintID` = compID;


    IF (row_count() > 0) THEN
        SELECT TRUE;
    END IF;
    COMMIT WORK;
END;

