create
    definer = pms@`%` procedure uspDashboardMaintenanceSupervisor_Owners()
BEGIN
    SELECT COUNT(o.OwnerID) AS totalOwner
    FROM Owner AS o
    WHERE o.Active = 1;
END;

