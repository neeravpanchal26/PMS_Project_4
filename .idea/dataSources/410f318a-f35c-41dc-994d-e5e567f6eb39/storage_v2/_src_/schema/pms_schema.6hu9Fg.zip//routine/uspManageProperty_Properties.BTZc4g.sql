create
  definer = PMS@`%` procedure uspManageProperty_Properties()
BEGIN
  SELECT p.PropertyID,
         p.Name,
         p.Address1,
         pt.ResidenceTypeDesc,
         CONCAT(o.Firstname, ' ', o.Lastname) AS Owner,
         ps.`Desc`
  FROM Property AS p,
       PropertyType AS pt,
       Owner AS o,
       PropertyStatus AS ps
  WHERE p.Type = pt.ResidenceTypeID
    AND p.OwnerID = o.OwnerID
    AND p.Status = ps.PropertyStatusID;
END;

