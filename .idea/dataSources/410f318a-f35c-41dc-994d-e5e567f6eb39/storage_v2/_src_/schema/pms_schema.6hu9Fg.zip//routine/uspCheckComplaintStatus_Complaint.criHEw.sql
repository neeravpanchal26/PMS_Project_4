create
    definer = pms@`%` procedure uspCheckComplaintStatus_Complaint(IN tenantID int)
BEGIN
    SELECT c.ComplaintID,c.Date,csc.Name
    FROM Complaint AS c,ComplaintSubCategory AS csc
    WHERE c.subCategoryID = csc.SubID
      AND c.Status != 4
      AND c.tenantID = tenantID;
END;

