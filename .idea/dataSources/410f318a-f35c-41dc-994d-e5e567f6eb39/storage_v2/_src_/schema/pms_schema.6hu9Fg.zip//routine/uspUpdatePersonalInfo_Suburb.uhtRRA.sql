create
  definer = pms@`%` procedure uspUpdatePersonalInfo_Suburb()
BEGIN
  SELECT s.SuburbID, s.SuburbName
  FROM Suburb AS s;
END;

