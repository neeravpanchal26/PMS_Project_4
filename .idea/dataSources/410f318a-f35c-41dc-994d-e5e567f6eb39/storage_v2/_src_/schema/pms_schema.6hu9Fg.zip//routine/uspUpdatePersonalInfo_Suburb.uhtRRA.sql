create
  definer = PMS@`%` procedure uspUpdatePersonalInfo_Suburb()
BEGIN
  SELECT s.SuburbID, s.SuburbName
  FROM Suburb AS s;
END;

