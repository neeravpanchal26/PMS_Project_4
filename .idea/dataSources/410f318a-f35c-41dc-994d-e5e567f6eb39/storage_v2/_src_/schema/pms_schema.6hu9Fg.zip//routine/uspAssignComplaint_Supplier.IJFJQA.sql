create
    definer = pms@`%` procedure uspAssignComplaint_Supplier()
BEGIN
   SELECT s.SupplierID,s.Name,s.email,st.`Desc`
          FROM Supplier AS s,SupplierType AS st
   WHERE s.typeID = st.SupplierTypeID AND s.Active = 1;
END;

