create
  definer = PMS@`%` procedure uspChangePassword_OldCheck(IN userID int, IN userPass varchar(20))
BEGIN
  SELECT User.Salt INTO @salt
  FROM User
  WHERE User.UserID = userID;

  IF (SELECT COUNT(User.userID)
      FROM User
      WHERE User.UserID = userID
        AND User.Hash = UNHEX(SHA1(CONCAT(HEX(@salt), userPass)))) != 1 THEN
    SELECT false AS result;
  ELSE
    SELECT true AS result;
  END IF;
END;

