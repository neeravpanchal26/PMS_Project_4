create
    definer = pms@`%` procedure uspUpdateSupplierInfo_UpdateInfo(IN supplierID int, IN name varchar(45), IN type int,
                                                                 IN contactNumber varchar(10), IN email varchar(200),
                                                                 IN address1 varchar(45), IN address2 varchar(45),
                                                                 IN suburb int)
BEGIN
    DECLARE errno INT;
    DECLARE EXIT
        HANDLER FOR SQLEXCEPTION
        BEGIN
            GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
            SELECT errno AS MYSQL_ERROR;
            ROLLBACK;
        END;

    START TRANSACTION;
    SET autocommit = 0;

    UPDATE `pms_schema`.`Supplier`
    SET `Name`          = name,
        `email`         = email,
        `contactNumber` = contactNumber,
        `typeID`        = type,
        `Address1`      = address1,
        `Address2`      = address2,
        `Suburb`        = suburb
    WHERE `SupplierID` = supplierID;

    IF
        (row_count() > 0)
    THEN
        SELECT TRUE;
    END IF;
    COMMIT WORK;
END;

