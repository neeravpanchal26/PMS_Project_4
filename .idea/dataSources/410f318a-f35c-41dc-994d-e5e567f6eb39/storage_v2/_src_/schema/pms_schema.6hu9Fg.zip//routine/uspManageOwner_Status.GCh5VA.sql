create
    definer = pms@`%` procedure uspManageOwner_Status(IN ownerID int, IN status int)
BEGIN
  DECLARE errno INT;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
      GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
      SELECT errno AS MYSQL_ERROR;
      ROLLBACK;
    END;
  START TRANSACTION;
  SET autocommit = 0;
    
  UPDATE Owner,Property
  SET Owner.Active = status,Property.Active = status
  WHERE Owner.OwnerID = ownerID AND Property.OwnerID = ownerID;

  COMMIT WORK;
END;

