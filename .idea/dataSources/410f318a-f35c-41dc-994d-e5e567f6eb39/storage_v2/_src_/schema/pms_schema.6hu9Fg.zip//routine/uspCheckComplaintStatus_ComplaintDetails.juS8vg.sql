create
    definer = pms@`%` procedure uspCheckComplaintStatus_ComplaintDetails(IN complaintID int)
BEGIN
    SELECT csc.Name,cd.`Desc` AS complaintDetailDesc,c.Date,cs.`Desc` AS statusDesc
    FROM Complaint AS c, ComplaintDetails AS cd,ComplaintSubCategory AS csc,ComplaintStatus AS cs
    WHERE c.ComplaintID = cd.complaintID AND csc.SubID = c.subCategoryID AND cd.statusID = cs.ComplaintStatusID AND cd.complaintID = complaintID;
END;

