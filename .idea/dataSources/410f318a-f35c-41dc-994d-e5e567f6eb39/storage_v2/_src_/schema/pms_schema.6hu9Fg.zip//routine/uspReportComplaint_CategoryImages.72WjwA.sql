create
    definer = pms@`%` procedure uspReportComplaint_CategoryImages()
BEGIN
   SELECT cc.Image
   FROM ComplaintCategory AS cc;
END;

