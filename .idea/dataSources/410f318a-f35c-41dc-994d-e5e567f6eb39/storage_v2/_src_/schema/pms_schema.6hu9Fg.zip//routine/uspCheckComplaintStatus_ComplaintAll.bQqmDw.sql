create
    definer = pms@`%` procedure uspCheckComplaintStatus_ComplaintAll(IN tenantID int)
BEGIN
    SELECT c.ComplaintID, c.Date, csc.Name
    FROM Complaint AS c,
         ComplaintSubCategory AS csc
    WHERE c.subCategoryID = csc.SubID
      AND c.tenantID = tenantID;
END;

