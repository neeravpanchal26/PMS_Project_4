create
  definer = pms@`%` procedure uspCreateUser_Suburb(IN cityID int)
BEGIN
  SELECT *
    FROM Suburb AS s
      WHERE s.CityID = cityID;
END;

