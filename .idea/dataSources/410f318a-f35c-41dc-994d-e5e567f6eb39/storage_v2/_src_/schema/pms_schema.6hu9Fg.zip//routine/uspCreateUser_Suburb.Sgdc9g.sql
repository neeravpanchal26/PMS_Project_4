create
  definer = PMS@`%` procedure uspCreateUser_Suburb(IN cityID int)
BEGIN
  SELECT *
    FROM Suburb
      WHERE CityID = cityID;
END;

