create
    definer = pms@`%` procedure uspBusinessSetting_LogoDownload()
BEGIN
  SELECT b.BusinessLogo
  FROM Business AS b
  WHERE b.BusinessID = 1;
END;

