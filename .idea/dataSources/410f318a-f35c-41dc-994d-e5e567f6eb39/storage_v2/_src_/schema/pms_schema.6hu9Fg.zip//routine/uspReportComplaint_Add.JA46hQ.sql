create
    definer = pms@`%` procedure uspReportComplaint_Add(IN propertyID int, IN tenantID int, IN description varchar(200),
                                                       IN subCategory int)
BEGIN
    -- Error Handling
    DECLARE errno INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
            SELECT errno AS MYSQL_ERROR;
            ROLLBACK;
        END;

    START TRANSACTION;
    SET autocommit = 0;
    SET @compID = (SELECT MAX(c.ComplaintID) + 1 FROM Complaint AS c);

    #Statement here
    INSERT INTO `pms_schema`.`Complaint`
    (`ComplaintID`,
     `propertyID`,
     `tenantID`,
     `subCategoryID`,
     `Desc`,
     `Image`,
     `Date`,
     `Status`)
    VALUES (@compID,
            propertyID,
            tenantID,
            subCategory,
            description,
            null,
            NOW(),
            1);

    IF (row_count() > 0) THEN
        SELECT TRUE;
    END IF;
    COMMIT WORK;
end;

