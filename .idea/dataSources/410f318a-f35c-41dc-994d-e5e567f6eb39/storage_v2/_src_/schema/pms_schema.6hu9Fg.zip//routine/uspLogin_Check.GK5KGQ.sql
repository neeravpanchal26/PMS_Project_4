create
    definer = pms@`%` procedure uspLogin_Check(IN email varchar(200), IN password varchar(50))
BEGIN
  SELECT u.UserID, u.Email, u.Salt, u.Type INTO @ID, @Email, @Salt, @Type FROM user AS u WHERE u.Email = email;
  IF (SELECT COUNT(u.UserID)
      FROM User AS u
      WHERE u.Email = email
        AND u.Hash = UNHEX(SHA1(CONCAT(HEX(@Salt), password)))) != 1 THEN
    SELECT FALSE;
  ELSE
    SELECT u.Active, CONCAT(u.FirstName, ' ', u.Surname, ' - (', ut.UserTypeDesc,')') AS username , u.UserID, ut.UserTypeID, ut.UserTypeDesc
    FROM User AS u, UserType AS ut
    WHERE u.UserID = @ID AND ut.UserTypeID = @Type;
    IF (SELECT u.Active FROM User AS u WHERE u.UserID = @ID) = 1 THEN
      INSERT INTO LoginHistory (LoginHistoryID, LoginHistoryDate) VALUES (@ID, NOW());
    END IF;
  END IF ;
END;

