create
    definer = pms@`%` procedure uspUserReport_Users(IN typeDesc varchar(45), IN cityName varchar(45),
                                                    IN suburbName varchar(45))
BEGIN
  SELECT u.UserID,CONCAT(u.FirstName,' ',u.Surname) AS username,u.ContactNumber,ut.UserTypeDesc,s.SuburbName,c.CityName
  FROM User AS u, UserType AS ut,Suburb AS s, City AS c
  WHERE u.Type = ut.UserTypeID AND u.Suburb = s.SuburbID AND s.CityID = c.CityID AND
        c.CityName LIKE CONCAT(cityName,'%') AND
        ut.UserTypeDesc LIKE CONCAT(typeDesc,'%') AND
        s.SuburbName LIKE CONCAT(suburbName,'%');
END;

