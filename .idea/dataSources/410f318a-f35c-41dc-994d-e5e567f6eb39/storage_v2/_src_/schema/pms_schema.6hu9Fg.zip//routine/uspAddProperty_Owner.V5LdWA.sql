create
  definer = pms@`%` procedure uspAddProperty_Owner()
BEGIN
  SELECT o.OwnerID,CONCAT(o.Firstname,' ',o.Lastname) AS fullName 
  FROM Owner AS o;
END;

