create
  definer = pms@`%` procedure uspAddProperty_PropType()
BEGIN
  SELECT *
  FROM PropertyType;
END;

