create
  definer = PMS@`%` procedure uspAddProperty_PropType()
BEGIN
  SELECT *
  FROM PropertyType;
END;

