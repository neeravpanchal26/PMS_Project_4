create
    definer = pms@`%` procedure uspDashboardMaintenanceSupervisor_Suppliers()
BEGIN
    SELECT COUNT(s.SupplierID) AS totalSupplier
    FROM Supplier AS s
    WHERE s.Active = 1;
END;

