create
  definer = pms@`%` procedure uspManageOwner_Owners()
BEGIN
  SELECT CONCAT(o.Firstname, ' ', o.Lastname) AS owner, o.ContactNumber,o.Email,COUNT(p.OwnerID) AS propertyCount, o.Active
  FROM Owner AS o, Property AS p
    WHERE o.OwnerID = p.OwnerID
    GROUP BY p.OwnerID;
END;

