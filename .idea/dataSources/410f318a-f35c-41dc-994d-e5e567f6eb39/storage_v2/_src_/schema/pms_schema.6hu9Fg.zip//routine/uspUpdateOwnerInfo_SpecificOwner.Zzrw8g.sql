create
    definer = pms@`%` procedure uspUpdateOwnerInfo_SpecificOwner(IN ownerID int)
BEGIN
  SELECT o.Firstname, o.Lastname, o.ContactNumber, o.Address1, o.Address2, o.Email, o.Suburb, c.CityID
  FROM Owner AS o,Suburb AS s, City AS c
  WHERE o.OwnerID = ownerID AND c.CityID = s.CityID;
END;

