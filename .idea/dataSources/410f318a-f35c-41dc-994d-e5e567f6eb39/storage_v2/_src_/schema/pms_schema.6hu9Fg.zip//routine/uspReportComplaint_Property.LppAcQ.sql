create
    definer = pms@`%` procedure uspReportComplaint_Property(IN tenantID int)
BEGIN
    SELECT p.PropertyID,p.Name
    FROM Property AS p
    WHERE p.TenantID = tenantID;
end;

