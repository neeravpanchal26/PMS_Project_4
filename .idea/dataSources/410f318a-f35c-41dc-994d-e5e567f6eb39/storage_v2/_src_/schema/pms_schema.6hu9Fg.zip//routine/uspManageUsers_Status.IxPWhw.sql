create
    definer = pms@`%` procedure uspManageUsers_Status(IN userID int, IN userStatus int)
BEGIN
	DECLARE errno INT;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
	GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
	SELECT errno AS MYSQL_ERROR;
	ROLLBACK;
	END;
	START TRANSACTION;
    SET autocommit=0;
		
        UPDATE User
		SET User.Active = userStatus
		WHERE User.UserID = userID;
        
    COMMIT WORK;
END;

