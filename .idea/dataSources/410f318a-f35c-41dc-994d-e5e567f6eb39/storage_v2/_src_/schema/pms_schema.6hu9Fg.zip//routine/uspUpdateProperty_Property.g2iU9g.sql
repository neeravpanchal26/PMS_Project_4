create
    definer = pms@`%` procedure uspUpdateProperty_Property(IN propertyID int)
BEGIN
  SELECT p.Name,p.OwnerID,p.Address1,p.Address2,p.Suburb,p.Status,p.Type,p.Bedrooms,p.Bathrooms,p.Size,p.YearBuilt, c.CityID
  FROM Property AS p,City AS c, Suburb AS s
  WHERE p.PropertyID = propertyID AND p.Suburb = s.SuburbID AND s.CityID = c.CityID;
END;

