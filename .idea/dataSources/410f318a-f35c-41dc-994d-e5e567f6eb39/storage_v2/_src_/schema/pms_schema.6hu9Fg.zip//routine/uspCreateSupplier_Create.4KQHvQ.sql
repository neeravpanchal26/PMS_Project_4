create
    definer = pms@`%` procedure uspCreateSupplier_Create(IN name varchar(45), IN type int, IN contactNumber varchar(10),
                                                         IN email varchar(200), IN address1 varchar(45),
                                                         IN address2 varchar(45), IN suburb int)
BEGIN
    -- Error Handling
    DECLARE errno INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
            SELECT errno AS MYSQL_ERROR;
            ROLLBACK;
        END;

    START TRANSACTION;
    SET autocommit = 0;
    SET @supplierID = (SELECT MAX(s.SupplierID) + 1 FROM Supplier AS s);

    #   Statement Here
    INSERT INTO `pms_schema`.`Supplier`
    (`SupplierID`,
     `Name`,
     `email`,
     `contactNumber`,
     `typeID`,
     `Active`,
     `Address1`,
     `Address2`,
     `Suburb`)
    VALUES (@supplierID,
            name,
            email,
            contactNumber,
            type,
            1,
            address1,
            address2,
            suburb);

    IF (row_count() > 0) THEN
        SELECT TRUE;
    END IF;
    COMMIT WORK;
END;

