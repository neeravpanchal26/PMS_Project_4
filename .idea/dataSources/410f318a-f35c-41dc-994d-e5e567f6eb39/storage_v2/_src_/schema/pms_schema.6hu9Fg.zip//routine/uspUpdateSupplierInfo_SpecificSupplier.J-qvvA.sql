create
    definer = pms@`%` procedure uspUpdateSupplierInfo_SpecificSupplier(IN supplierID int)
BEGIN
    SELECT sp.Name,
           sp.typeID,
           sp.contactNumber,
           sp.email,
           sp.Address1,
           sp.Address2,
           c.CityID,
           sp.Suburb
    FROM Supplier AS sp,
         Suburb AS s,
         City AS c
    WHERE sp.SupplierID = supplierID
      AND c.CityID = s.CityID;
END;

