create
    definer = pms@`%` procedure uspAddProperty_PropStatus()
BEGIN
  SELECT *
  FROM PropertyStatus;
END;

