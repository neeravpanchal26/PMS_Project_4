create
  definer = PMS@`%` procedure uspAddProperty_PropStatus()
BEGIN
  SELECT *
  FROM PropertyStatus;
END;

