create
    definer = pms@`%` procedure uspCreateUser_City()
BEGIN
  SELECT *
    FROM City;
END;

