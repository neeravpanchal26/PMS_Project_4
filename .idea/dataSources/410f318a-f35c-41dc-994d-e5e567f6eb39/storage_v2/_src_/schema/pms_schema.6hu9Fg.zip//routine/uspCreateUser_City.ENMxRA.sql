create
  definer = PMS@`%` procedure uspCreateUser_City()
BEGIN
  SELECT *
    FROM City;
END;

