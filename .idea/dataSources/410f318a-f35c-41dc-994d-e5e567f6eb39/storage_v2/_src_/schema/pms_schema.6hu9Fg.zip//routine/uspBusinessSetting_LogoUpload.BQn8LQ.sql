create
    definer = pms@`%` procedure uspBusinessSetting_LogoUpload(IN logo longblob)
BEGIN
  UPDATE Business
  SET Business.BusinessLogo = logo
  WHERE Business.BusinessID = 1;
END;

