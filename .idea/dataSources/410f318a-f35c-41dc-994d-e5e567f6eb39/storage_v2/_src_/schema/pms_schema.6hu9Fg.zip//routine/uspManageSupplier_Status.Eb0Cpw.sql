create
    definer = pms@`%` procedure uspManageSupplier_Status(IN supplierID int, IN status int)
BEGIN
    DECLARE errno INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
            SELECT errno AS MYSQL_ERROR;
            ROLLBACK;
        END;
    START TRANSACTION;
    SET autocommit = 0;

    UPDATE Supplier
        SET Supplier.Active = status
        WHERE Supplier.SupplierID = supplierID;

    COMMIT WORK;
END;

