create
    definer = pms@`%` procedure uspAssignProperty_Add(IN propertyID int, IN tenantID int, IN startDate varchar(10),
                                                      IN endDate varchar(10))
BEGIN
    -- Error Handling
    DECLARE errno INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
            SELECT errno AS MYSQL_ERROR;
            ROLLBACK;
        END;

    START TRANSACTION;
    SET autocommit = 0;
    SET @propID = (SELECT MAX(pt.PropertyTenantID) + 1 FROM PropertyTenant AS pt);

    # Statement here
    INSERT INTO PropertyTenant
    (`propertyID`,
     `tenantID`,
     `startDate`,
     `endDate`,
     `PropertyTenantID`)
    VALUES (propertyID,
            tenantID,
            startDate,
            endDate,
            @propID);

    UPDATE Property AS p SET p.TenantID = tenantID, p.Status = 1 WHERE p.PropertyID = propertyID;

    UPDATE User AS u
    SET u.Address1 = (SELECT p.Address1 FROM Property AS p WHERE p.PropertyID = propertyID),
        u.Address2 = (SELECT p.Address2 FROM Property AS p WHERE p.PropertyID = propertyID),
        u.Suburb   = (SELECT p.Suburb FROM Property AS p WHERE p.PropertyID = propertyID)
    WHERE u.UserID = tenantID;

    IF (row_count() > 0) THEN
        SELECT TRUE;
    END IF;
    COMMIT WORK;
END;

