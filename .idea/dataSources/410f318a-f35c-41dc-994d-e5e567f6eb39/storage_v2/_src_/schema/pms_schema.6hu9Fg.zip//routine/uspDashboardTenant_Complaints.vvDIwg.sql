create
    definer = pms@`%` procedure uspDashboardTenant_Complaints(IN tenantID int, IN days int)
BEGIN
    SELECT t1.reportedDate, COALESCE(SUM(t1.totalComplaints + t2.totalComplaints),0) AS totalComplaints
    FROM
        (
            SELECT DATE(a.Date) AS reportedDate, 0 AS totalComplaints
            FROM
                (
                    SELECT CURDATE() - INTERVAL (a.a +(10 * b.a)+(100*c.a)) DAY as Date
                    FROM(select 0 as a union all select 1 union all select 2 union all select 3 union all select 4 union all select 5 union all select 6 union all select 7 union all select 8 union all select 9) as a
                            cross join (select 0 as a union all select 1 union all select 2 union all select 3 union all select 4 union all select 5 union all select 6 union all select 7 union all select 8 union all select 9) as b
                            cross join (select 0 as a union all select 1 union all select 2 union all select 3 union all select 4 union all select 5 union all select 6 union all select 7 union all select 8 union all select 9) as c
                ) a
            WHERE a.Date BETWEEN NOW() - INTERVAL days DAY AND NOW()
        ) t1
            LEFT JOIN
        (
            SELECT COALESCE(COUNT(c.ComplaintID),0) AS totalComplaints, DATE(c.Date) AS reportedDate
            FROM Complaint AS c
            WHERE c.Date BETWEEN NOW() + INTERVAL - days DAY AND NOW() + INTERVAL 0 DAY
              AND c.tenantID = tenantID
            GROUP BY DATE(c.Date)
        ) t2
        ON t2.reportedDate = t1.reportedDate
    GROUP BY t1.reportedDate;
END;

