create
    definer = pms@`%` procedure uspDashboardTenant_Complaints(IN tenantID int, IN days int)
BEGIN
    SELECT COUNT(c.ComplaintID) AS totalComplaints, DATE(c.Date) AS reportedDate
    FROM Complaint AS c
    WHERE c.Date BETWEEN NOW() + INTERVAL - days DAY AND NOW() + INTERVAL 0 DAY
      AND c.tenantID = tenantID
    GROUP BY DATE(c.Date);
END;

