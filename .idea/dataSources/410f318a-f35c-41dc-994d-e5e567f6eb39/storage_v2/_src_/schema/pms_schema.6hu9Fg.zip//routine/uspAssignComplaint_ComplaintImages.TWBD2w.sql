create
    definer = pms@`%` procedure uspAssignComplaint_ComplaintImages(IN compID int)
BEGIN
    SELECT c.Image
    FROM Complaint AS c
    WHERE c.ComplaintID = compID;
END;

