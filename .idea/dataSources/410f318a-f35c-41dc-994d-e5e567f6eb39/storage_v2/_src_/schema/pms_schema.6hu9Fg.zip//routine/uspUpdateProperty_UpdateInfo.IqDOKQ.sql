create
    definer = pms@`%` procedure uspUpdateProperty_UpdateInfo(IN PropID int, IN Name varchar(45),
                                                             IN Address1 varchar(45), IN Address2 varchar(45),
                                                             IN Suburb int, IN YearBuilt varchar(4), IN PropType int,
                                                             IN Owner int, IN Bedrooms int, IN Bathrooms int,
                                                             IN Size int, IN PropStatus int)
BEGIN
  DECLARE errno INT;
  DECLARE EXIT
    HANDLER FOR SQLEXCEPTION
    BEGIN
      GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
      SELECT errno AS MYSQL_ERROR;
      ROLLBACK;
    END;

  START TRANSACTION;
  SET autocommit = 0;

  UPDATE Property AS p
  SET p.Name      = Name,
      p.Address1  = Address1,
      p.Address2  = Address2,
      p.Suburb    = Suburb,
      p.YearBuilt = YearBuilt,
      p.Type      = PropType,
      p.OwnerID   = Owner,
      p.Bedrooms  = Bedrooms,
      p.Bathrooms = Bathrooms,
      p.Size      = Size,
      p.Status    = PropStatus
  WHERE p.PropertyID = PropID;
  
  IF
    (row_count() > 0)
  THEN
    SELECT TRUE;
  END IF;
  COMMIT WORK;
END;

