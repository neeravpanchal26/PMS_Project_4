create
  definer = pms@`%` procedure uspCreateUser_UserType()
BEGIN
    SELECT *
    FROM UserType;
END;

