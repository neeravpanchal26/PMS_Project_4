create
  definer = PMS@`%` procedure uspCreateUser_UserType()
BEGIN
    SELECT *
    FROM UserType;
END;

