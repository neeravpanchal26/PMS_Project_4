create
    definer = pms@`%` procedure uspCreateUser_UserType()
BEGIN
    SELECT *
    FROM UserType AS ut
    WHERE ut.UserTypeID != 2;
END;

