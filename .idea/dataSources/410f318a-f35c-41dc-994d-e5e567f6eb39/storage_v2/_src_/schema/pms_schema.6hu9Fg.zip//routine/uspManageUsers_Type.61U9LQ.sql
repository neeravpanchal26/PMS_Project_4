create
    definer = pms@`%` procedure uspManageUsers_Type(IN userID int, IN userType int)
BEGIN
	DECLARE errno INT;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
	GET CURRENT DIAGNOSTICS CONDITION 1 errno = MYSQL_ERRNO;
	SELECT errno AS MYSQL_ERROR;
	ROLLBACK;
	END;
	START TRANSACTION;
    SET autocommit=0;
		
        UPDATE User
		SET User.Type = userType
		WHERE User.UserID = userID;
        
    COMMIT WORK;
END;

