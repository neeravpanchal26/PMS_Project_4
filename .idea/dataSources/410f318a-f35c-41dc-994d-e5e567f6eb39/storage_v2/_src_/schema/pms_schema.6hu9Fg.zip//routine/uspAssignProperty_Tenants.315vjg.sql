create
  definer = pms@`%` procedure uspAssignProperty_Tenants()
BEGIN
  SELECT u.UserID,CONCAT(u.FirstName,' ',u.Surname) AS fullName
  FROM User AS u
  WHERE u.Type = 2;
END;

