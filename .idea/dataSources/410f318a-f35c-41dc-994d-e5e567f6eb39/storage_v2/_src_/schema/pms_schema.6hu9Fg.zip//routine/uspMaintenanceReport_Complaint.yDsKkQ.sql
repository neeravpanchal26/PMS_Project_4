create
    definer = pms@`%` procedure uspMaintenanceReport_Complaint(IN propName varchar(45), IN tenantName varchar(45),
                                                               IN subCat varchar(45), IN cat varchar(45),
                                                               IN ownerName varchar(45), IN complaintStatus varchar(45),
                                                               IN startDate varchar(10), IN endDate varchar(10))
BEGIN
    SELECT C.Date, C.`Desc`
    FROM Complaint AS C,
         Property AS P,
         User AS U,
         ComplaintSubCategory AS CSC,
         ComplaintCategory AS CC,
         Owner AS O,
         ComplaintStatus AS CS
    WHERE C.propertyID = p.PropertyID
      AND C.tenantID = U.UserID
      AND CSC.SubID = C.subCategoryID
      AND CC.CategoryID = CSC.CategoryID
      AND P.OwnerID = O.OwnerID
      AND CS.ComplaintStatusID = C.Status
      AND p.Name LIKE CONCAT(propName, '%')
      AND CONCAT(u.FirstName, ' ', u.Surname) LIKE CONCAT(tenantName, '%')
      AND CSC.Name LIKE CONCAT(subCat, '%')
      AND CC.Name LIKE CONCAT(cat, '%')
      AND CONCAT(o.Firstname, ' ', o.Lastname) LIKE CONCAT(ownerName, '%')
      AND CS.`Desc` LIKE CONCAT(complaintStatus, '%')
      AND C.Date BETWEEN startDate and endDate;
END;

